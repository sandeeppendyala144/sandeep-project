import java.util.Scanner;
class foodtruck
{
public static void main(String[]args)
{
Scanner scnew Scanner(System.in);
System.out.println("welcome to the indian restuarant foodtruck");
System.out.println("please give me your order sir takeway/not");
String a=sc.next[];
System.out.println("please give me number of plates");
int b=sc.nextInt();
System.out.println("thank you sir could like to give some feedback y/n");
char c=sc.nextchar();
switch(c)
{
case'y'
System.out.println("thank you for your feedback sir");
break;
case'n'
System.out.println("thank you sir visit again");
break;
}
