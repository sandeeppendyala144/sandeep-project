import java.util.Scanner;
class customer
{
Scanner sc=new Scanner(System.in)
String order[]=sc.nextline[];
String cash[]=sc.nextline[];
public order(String order,String cash)
{
this.order=order;
this.cash=cash;
}
public cash()
{
return this.cash;
}
