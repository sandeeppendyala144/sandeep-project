class customerorder extend thread
{
customerorder s;
thread a;
givenorder(customerorder s)
{
this.s=s;
a=new Thread;
a.start();
}
public void run()
{
for(int i=0;i<=2;i++)
{
s.customerorder(a);
}
}
class resturant
{
public static void main(string[]args)
{
customerorder s=new customerorder;
new.givenorder(a);
}
}

