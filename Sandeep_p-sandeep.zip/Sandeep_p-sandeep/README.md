# Sandeep_p
Restaurant management system
